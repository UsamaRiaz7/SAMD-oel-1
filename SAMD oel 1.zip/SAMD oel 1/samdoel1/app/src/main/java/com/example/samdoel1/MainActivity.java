package com.example.samdoel1;

import static android.text.TextUtils.isEmpty;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    protected <LoginActivity> void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText username;
        EditText password;
        Button login;

        private void setupUI setupUI();
        private void setupListeners setupListeners();
         {


                private void checkUsername() {
                    boolean isValid = true;
                }
            });
        }
        void checkUsername () {
            boolean isValid = true;
            EditText username = null;
            if (isEmpty((CharSequence) username)) {
                username.setError("You must enter username to login!");
                isValid = false;
            } else {
                if (!isEmail(username)) {
                    username.setError("Enter valid email!");
                    isValid = false;
                }
            }

            AccessibilityNodeInfo password = null;
            if (isEmpty((CharSequence) password)) {
                password.setError("You must enter password to login!");
                isValid = false;
            } else {
                if (password.getText().toString().length() < 4) {
                    password.setError("Password must be at least 4 chars long!");
                    isValid = false;
                }
            }

            if (isValid) {
                String usernameValue = username.getText().toString();
                String passwordValue = password.getText().toString();
                if (usernameValue.equals("test@test.com") && passwordValue.equals("password1234")) {
                    //everything checked we open new activity
                    Intent i = new Intent(String.valueOf(MainActivity.class));
                    startActivity(i);
                    //we close this activity
                    this.finish();
                } else {
                    Toast t = Toast.makeText(this, "Wrong email or password!", Toast.LENGTH_SHORT);
                    t.show();
                }
            }
        }
    }

    private void setupListeners() {
        View login;
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        }
        public void onClick(View Object v;){
                checkUsername();
            }
    }

    private void setupUI() {
        View username = findViewById(R.id.editUsername);
        View password = findViewById(R.id.editTextpass);
        View login = findViewById(R.id.loginbutton);
    }
        private boolean isEmail(EditText username) {
        return false;
    }
}



